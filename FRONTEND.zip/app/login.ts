export class Login {
    constructor(public emailid:string,
        public username:string,
        public password:string,
        public location:string,
        public typeOfUser:string){}
}
