package com.example.MyMoviePlan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootBackendMyMoviePlanApplicationTests {

	@Test
	void contextLoads() {
	}

}
